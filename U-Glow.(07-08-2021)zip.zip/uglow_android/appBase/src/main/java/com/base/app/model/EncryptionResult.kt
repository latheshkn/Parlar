package com.base.app.model

data class  EncryptionResult(
    var cryptString:String?=null,
    var IV:String?=null
)