package com.base.app.model

data class ErrorResponse(
    var status : Int? = -1,
    var message :String? = null
)