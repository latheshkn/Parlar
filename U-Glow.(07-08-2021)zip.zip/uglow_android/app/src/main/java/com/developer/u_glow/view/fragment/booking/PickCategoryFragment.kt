package com.developer.u_glow.view.fragment.booking

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.base.app.utils.navigateTo
import com.base.app.view.BaseFragment
import com.developer.u_glow.R
import com.developer.u_glow.adapter.PeopleAdapter
import com.developer.u_glow.databinding.FragmentPickCategoryBinding
import com.developer.u_glow.model.dto.CategoryData
import com.developer.u_glow.model.dto.PostGlowData
import com.developer.u_glow.state.booking.PickCategoryState

import com.developer.u_glow.viewmodel.booking.PickCategoryViewModel
import org.parceler.Parcels
import timber.log.Timber


class PickCategoryFragment(override val layoutId: Int = R.layout.fragment_pick_category) :
    BaseFragment<PickCategoryViewModel, FragmentPickCategoryBinding>() {
    var list: ArrayList<CategoryData> = ArrayList()
    override val mViewModel: PickCategoryViewModel by viewModels()
    val args: PickCategoryFragmentArgs by navArgs()
    var position: String? = null
    var forMe: Boolean? = false
    var forGroup: Boolean? = false
    var id: String? = null

    override fun subscribeObservers() {
        mViewModel.stateObserver.observe(this, Observer {
            when (it) {

                is PickCategoryState.SetPeopleAdapter -> {
                    mViewBinding.spinner.adapter = PeopleAdapter(requireContext(), it.list)

                }

                is PickCategoryState.UpdatePickCategoryAdapter -> {
                    mViewBinding.rvCategory.adapter = it.adapter
                    list = it.adapter?.data as ArrayList<CategoryData>
                }
                is PickCategoryState.HideAndShowForMe -> {

                    hideAndShowForMe(it.forMe, it.forGroup)

                    mViewBinding.tvGlowHistory.setOnClickListener { view ->

                        it.id.let {
                            val bundle = Bundle()
                            val postGlow=PostGlowData(id=it!!)
                            bundle.putParcelable("post", postGlow )
                            findNavController().navigateTo(
                                R.id.nav_select_sub_category_fragment,
                                bundle
                            )
                        }

                        Timber.d("idchecking ${it.id}")
                    }

                }

                else -> {
                }
            }
        })

        mViewBinding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                mViewModel.getFilterData(p0.toString(), list, requireContext())
            }
        })


    }

    override fun onFragmentCreated() {
        mViewBinding.view = this
        position = args.position
        id = args.id
        forMe = args.forMe
        forGroup = args.forGroup

//        if (forMe != null && forGroup != null) {
//            hideAndShowForMe(forMe!!, forGroup!!)
//        }

//        mViewModel.getAllCategory(position!!, mViewModel)


    }

    private fun hideAndShowForMe(forMe: Boolean, forGroup: Boolean) {
        mViewBinding.ivGroup.isVisible = forGroup
        mViewBinding.tvGroup.isVisible = forGroup
        mViewBinding.tvPeople.isVisible = forGroup
        mViewBinding.spinner.isVisible = forGroup
        mViewBinding.ivJustMe.isVisible = forMe
        mViewBinding.tvJustMe.isVisible = forMe
    }



}