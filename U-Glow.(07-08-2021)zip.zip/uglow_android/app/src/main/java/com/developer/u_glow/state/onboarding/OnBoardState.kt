package com.developer.u_glow.state.onboarding

sealed class OnBoardState {
    object Init : OnBoardState()
}