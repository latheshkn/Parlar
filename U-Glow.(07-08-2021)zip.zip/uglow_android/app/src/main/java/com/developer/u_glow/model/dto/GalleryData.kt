package com.developer.u_glow.model.dto

data class GalleryData(
    var galleryImage:Int?=null
)