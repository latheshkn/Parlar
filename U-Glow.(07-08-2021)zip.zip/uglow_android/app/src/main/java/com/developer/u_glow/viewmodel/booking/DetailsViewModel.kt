package com.developer.u_glow.viewmodel.booking

import android.os.Bundle
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.state.booking.DetailsState

class DetailsViewModel : BaseViewModel<DetailsState>() {


    private var state: DetailsState = DetailsState.Init
        set(value) {
            field = value
            publishState(state)
        }

    override fun onInitialized(bundle: Bundle?) {
    }

}