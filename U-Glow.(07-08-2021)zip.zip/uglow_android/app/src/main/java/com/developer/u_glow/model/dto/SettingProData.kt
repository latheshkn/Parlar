package com.developer.u_glow.model.dto

data class SettingProData(
    var day:String?=null
)
