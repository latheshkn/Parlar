package com.developer.u_glow.adapter.viewholder

import com.base.app.adapter.BaseViewHolder
import com.base.app.utils.loadCircleImage
import com.base.app.utils.loadUrl
import com.developer.u_glow.R
import com.developer.u_glow.databinding.InflateCategoryBinding
import com.developer.u_glow.model.dto.CategoryData
import com.developer.u_glow.viewmodel.booking.DashboardViewModel
import com.developer.u_glow.viewmodel.booking.PickCategoryViewModel
import com.developer.u_glow.viewmodel.booking.SelectSubCategoryViewModel
import okhttp3.internal.notify
import timber.log.Timber

class PickCategoryViewHolder(
    view: InflateCategoryBinding,
    private val viewModel: Any? = null,
    var lastItemSelectedPos: Int? = null
) : BaseViewHolder<CategoryData, InflateCategoryBinding>(view) {
    var selectedItemPos = -1
    var previousPos = -1
    var select: Boolean = false
    override fun populateData(data: CategoryData) {


        viewBinding.root.setOnClickListener {

            if (previousPos == -1) {
                previousPos = adapterPosition
            }
            when (viewModel) {
                is DashboardViewModel -> {
                    viewModel.onClickCategory(adapterPosition, data)
                }

                is SelectSubCategoryViewModel -> {
                    viewModel.onClickSubCategory(adapterPosition, data)
                }
                is PickCategoryViewModel -> {
                    viewModel.onClickSubCategory(adapterPosition, data, previousPos)

                }
            }


        }
        if (data.select) data.greenImage?.let {
            viewBinding.ivCategory.loadUrl(data.greenImage)
        } else {
            viewBinding.ivCategory.loadUrl(data.image)

        }
        data.name?.let {
            viewBinding.tvCategory.text = it
        }

    }


}