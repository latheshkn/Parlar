package com.developer.u_glow.state.profile

sealed class YourProfileState{

}
