package com.developer.u_glow.model.dto

data class ReviewData(

    var pName:String?=null,
    var postedDate:String?=null,
    var rDescription:String?=null

)
