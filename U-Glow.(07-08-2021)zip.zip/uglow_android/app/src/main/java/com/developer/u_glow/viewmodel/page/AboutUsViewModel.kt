package com.developer.u_glow.viewmodel.page

import android.os.Bundle
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.state.page.AboutUsFragmentState

class AboutUsViewModel : BaseViewModel<AboutUsFragmentState>() {
    override fun onInitialized(bundle: Bundle?) {

    }
}