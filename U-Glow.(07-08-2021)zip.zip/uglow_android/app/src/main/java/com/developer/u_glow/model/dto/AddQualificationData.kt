package com.developer.u_glow.model.dto

data class AddQualificationData(
    var qualification:String?=null,
    var qualificationDetail:String?=null,
)
