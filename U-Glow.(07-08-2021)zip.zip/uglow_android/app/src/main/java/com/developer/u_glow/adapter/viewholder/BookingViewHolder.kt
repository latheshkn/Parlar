package com.developer.u_glow.adapter.viewholder

import com.base.app.adapter.BaseViewHolder
import com.developer.u_glow.databinding.InflateBookingBinding
import com.developer.u_glow.model.dto.BookingData
import com.developer.u_glow.viewmodel.booking.BookingViewModel
import com.developer.u_glow.viewmodel.booking.OpenGlowViewModel

class BookingViewHolder(
    view: InflateBookingBinding,
    private val isShowEdit: Boolean,
    val type: Int,
    private val viewModel: Any
) : BaseViewHolder<BookingData, InflateBookingBinding>(view) {
    override fun populateData(data: BookingData) {
        viewBinding.isShowEdit = isShowEdit
        viewBinding.type = type
        viewBinding.tvOffers.setOnClickListener {
            when(viewModel){
                is OpenGlowViewModel -> {
                    viewModel.onClickMakeOffer(adapterPosition, data)
                }

                is BookingViewModel -> {
                    viewModel.onClickGlow(adapterPosition, data)
                }
            }
        }
    }
}