package com.developer.u_glow.model.dto

data class ServiceData(
    val greenImage: String? ="",
    val id: Int? =null,
    val image: String? ="",
    val name: String? ="",
    val masterServiceId: Int? =null
)
