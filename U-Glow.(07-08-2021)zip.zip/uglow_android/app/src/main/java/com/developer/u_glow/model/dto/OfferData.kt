package com.developer.u_glow.model.dto

data class OfferData(
    var title: String? = null,
    var location: String? = null
)