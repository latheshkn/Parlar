package com.developer.u_glow.model.dto

data class PeopleData(
    var id: Int? = null,
    var name: String? = null,
)