package com.developer.u_glow.model.dto

data class SelectSubServiceData(var name:String)