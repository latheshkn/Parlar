package com.developer.u_glow.state.authenticate

sealed class RegisterTwoState {
    object Init : RegisterTwoState()
}