package com.developer.u_glow.view.fragment.booking

import android.os.Bundle
import android.os.Parcelable
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.base.app.utils.navigateTo
import com.base.app.view.BaseFragment
import com.developer.u_glow.R
import com.developer.u_glow.UGrowApp
import com.developer.u_glow.databinding.FragmentDashboardBinding
import com.developer.u_glow.model.dto.CategoryData
import com.developer.u_glow.model.dto.PostGlowData
import com.developer.u_glow.model.dto.SelectGlowData
import com.developer.u_glow.state.booking.DashboardState
import com.developer.u_glow.viewmodel.booking.DashboardViewModel
import org.parceler.Parcels

class DashboardFragment(override val layoutId: Int = R.layout.fragment_dashboard) :
    BaseFragment<DashboardViewModel, FragmentDashboardBinding>() {
    var list = ArrayList<CategoryData>()
    override val mViewModel: DashboardViewModel by viewModels()

    override fun subscribeObservers() {

        mViewModel.stateObserver.observe(this, Observer {
            when (it) {
                is DashboardState.UpdateCategoryAdapter -> {
                    mViewBinding.rvCategory.adapter = it.adapter
                    list.clear()
                    list.addAll(it.adapter?.data!!)
                    mViewBinding.tvAllCategory.setOnClickListener {
                        mViewModel.showMore(true, list)
                        mViewBinding.tvAllCategory.isVisible = false
                    }
                }

                is DashboardState.UpdateBookingAdapter -> {
                    mViewBinding.rvBooking.adapter = it.adapter
                }

                is DashboardState.NavigateToSubCategory -> {
                    val bundle = Bundle()
                    val postGlow=PostGlowData(it.position.toString(),it.data.forMe!!,it.data.forGroup!!,it.data.id!!)
                    bundle.putParcelable("post", postGlow)
                    findNavController().navigateTo(R.id.nav_pick_category_fragment, bundle)
                }
                is DashboardState.ShowMore -> {
                    mViewBinding.tvAllCategory.isVisible = it.showMore
                }

                else -> {

                }
            }
        })
    }

    fun onClickAllCategory() {
//        findNavController().navigateTo(R.id.action_to_pick_category)
    }

    override fun onFragmentCreated() {
        mViewBinding.view = this
//        mViewBinding.tvAllCategory.setOnClickListener({
//            val bundle = Bundle()
//            val postGlow=PostGlowData("1",false,true,"10")
//            bundle.putParcelable("post", Parcels.wrap(postGlow))
//            findNavController().navigateTo(R.id.nav_pick_category_fragment, bundle)
//        })
    }

    fun onClickHistory() {
        findNavController().navigateTo(R.id.nav_booking_fragment)
    }


}