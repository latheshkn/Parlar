package com.developer.u_glow.adapter

import android.view.ViewGroup
import com.base.app.adapter.BaseRecyclerAdapter
import com.developer.u_glow.R
import com.developer.u_glow.adapter.viewholder.PickCategoryViewHolder
import com.developer.u_glow.databinding.InflateCategoryBinding
import com.developer.u_glow.model.dto.CategoryData
import timber.log.Timber

class PickCategoryAdapter(
    var list: MutableList<CategoryData>? = null,
    private val viewModel: Any? = null, private var IsLoadMore: Boolean = false
) : BaseRecyclerAdapter<CategoryData, PickCategoryViewHolder>(list) {
    var selectedItemPos = -1
    var lastItemSelectedPos = -1
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PickCategoryViewHolder {
        return PickCategoryViewHolder(
            inflateDataBinding(
                R.layout.inflate_category,
                parent
            ) as InflateCategoryBinding, viewModel, lastItemSelectedPos
        )
    }


    fun updateList(searchedList: MutableList<CategoryData>) {
        Timber.d("adapterlist ${searchedList}")
        list = searchedList
        notifyDataSetChanged()
    }

    fun getAdapterPosition(lastPos: Int) {
        Timber.d("listchecking ${list.toString()}")
        list?.forEach {
            if (it.select == true){
                it.select=false
            }
        }
        list!![lastPos].select= true
        notifyDataSetChanged()
        Timber.d("listchecking ${list.toString()}")
    }

}