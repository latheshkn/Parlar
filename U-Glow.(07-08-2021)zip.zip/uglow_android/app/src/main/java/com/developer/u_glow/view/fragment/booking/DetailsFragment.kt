package com.developer.u_glow.view.fragment.booking


import android.annotation.SuppressLint
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.base.app.view.BaseFragment
import com.developer.u_glow.R
import com.developer.u_glow.databinding.FragmentDetailsBinding
import com.developer.u_glow.viewmodel.booking.DetailsViewModel
import com.developer.u_glow.viewmodel.booking.SelectGlowViewModel


class DetailsFragment :  BaseFragment<DetailsViewModel, FragmentDetailsBinding>() {
    override val mViewModel: DetailsViewModel by viewModels()
    override val layoutId: Int
        get() = R.layout.fragment_details

    override fun subscribeObservers() {

    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onFragmentCreated() {
        mViewBinding.view =this

        mViewBinding.cardEnterDetailsWant.setOnTouchListener { p0, p1 ->
            if (p0?.id == R.id.cardEnterDetailsWant) {
                p0.parent.requestDisallowInterceptTouchEvent(true)
            }
            false
        }


        mViewBinding.edtYourAddress.addTextChangedListener(object :TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                mViewBinding.selected=true
            }
            override fun afterTextChanged(p0: Editable?) {
            }

        })
    }

    fun onClickNavigation(){
        findNavController().navigate(R.id.nav_glow_posted_fragment)
    }


    fun onClickChangeColor(){
        mViewBinding.selected = !mViewBinding.selected
    }

}