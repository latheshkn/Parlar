package com.developer.u_glow.model.dto

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class SampleData(
    var id:Int?=null,
    var nvigationFrom:String="SelectGlow"
):Parcelable
