package com.developer.u_glow.adapter.viewholder

import com.base.app.adapter.BaseViewHolder
import com.developer.u_glow.databinding.InflateAddServiceBinding
import com.developer.u_glow.model.dto.SelectGlowData
import com.developer.u_glow.model.dto.ServiceData
import com.developer.u_glow.viewmodel.booking.SelectGlowViewModel

class AddServiceViewHolder(view: InflateAddServiceBinding,var viewModel: SelectGlowViewModel) :
    BaseViewHolder<ServiceData, InflateAddServiceBinding>(view) {

    override fun populateData(data: ServiceData) {

         viewBinding.data=data
        viewBinding.listener=viewModel
        viewBinding.position=adapterPosition


    }
}