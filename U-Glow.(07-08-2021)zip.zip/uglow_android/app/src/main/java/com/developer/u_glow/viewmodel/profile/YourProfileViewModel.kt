package com.developer.u_glow.viewmodel.profile

import android.os.Bundle
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.state.profile.YourProfileState

class YourProfileViewModel:BaseViewModel<YourProfileState>() {
    override fun onInitialized(bundle: Bundle?) {

    }
}