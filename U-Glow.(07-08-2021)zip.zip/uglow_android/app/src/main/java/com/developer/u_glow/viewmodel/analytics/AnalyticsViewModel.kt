package com.developer.u_glow.viewmodel.analytics

import android.os.Bundle
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.state.analytics.AnalyticsFragmentState

class AnalyticsViewModel:BaseViewModel<AnalyticsFragmentState>() {
    override fun onInitialized(bundle: Bundle?) {

    }
}