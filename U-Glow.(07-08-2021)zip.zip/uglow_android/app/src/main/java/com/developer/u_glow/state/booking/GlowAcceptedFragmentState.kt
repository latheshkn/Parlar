package com.developer.u_glow.state.booking

sealed class GlowAcceptedFragmentState{

}
