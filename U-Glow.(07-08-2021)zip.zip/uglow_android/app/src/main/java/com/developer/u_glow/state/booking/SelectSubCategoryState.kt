package com.developer.u_glow.state.booking

import com.developer.u_glow.adapter.CategoryAdapter
import com.developer.u_glow.model.dto.CategoryData
import com.developer.u_glow.model.dto.PeopleData

sealed class SelectSubCategoryState {
    object Init : SelectSubCategoryState()
    data class UpdateCategoryAdapter(var adapter: CategoryAdapter?) : SelectSubCategoryState()
    data class NavigateToSubCategory(var data: CategoryData) : SelectSubCategoryState()
}