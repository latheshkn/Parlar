package com.developer.u_glow.model.dto

data class SelectGlowData(
    var glowName:String?=null,
    var id:Int?=null,
)
