package com.developer.u_glow.state.authenticate

sealed class RegisterState {
    object Init : RegisterState()
}