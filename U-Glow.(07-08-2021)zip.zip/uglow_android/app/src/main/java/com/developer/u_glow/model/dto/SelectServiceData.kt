package com.developer.u_glow.model.dto

class SelectServiceData(
    var serviceName:String?=null,

)