package com.developer.u_glow.util

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import com.developer.u_glow.model.dto.ServiceData
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object PrefConfig {

    var list: ArrayList<ServiceData> = ArrayList()
    lateinit var sharedPref: SharedPreferences

    public fun WriteList(data: ServiceData) {

        list.add(data)
        val gson = Gson()
        val jsonString = gson.toJson(list)

        val editer = sharedPref.edit()
        editer.putString("List_key", jsonString)
        editer.apply()
    }

    public fun readList(): List<ServiceData>? {

        val jsonString = sharedPref.getString("List_key", "")
        val gson = Gson()
        val turnsType = object : TypeToken<List<ServiceData>>() {}.type

        val list = gson.fromJson<ArrayList<ServiceData>>(jsonString, turnsType)

        if (!list.isNullOrEmpty()) {
            return list
        } else {
            return null
        }


    }

    public fun clearPref() {
        val editer = sharedPref.edit()
        editer.clear()
        editer.apply()
    }


    fun Initialize(ctxt: Context) {

        sharedPref = ctxt.getSharedPreferences(
            "MysharedPref", Context.MODE_PRIVATE
        )
    }

}