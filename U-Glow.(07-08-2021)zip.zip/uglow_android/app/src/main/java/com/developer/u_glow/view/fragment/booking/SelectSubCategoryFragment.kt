package com.developer.u_glow.view.fragment.booking

import android.content.Intent
import android.os.Bundle
import android.os.Parcelable
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.base.app.utils.Toaster
import com.base.app.utils.navigateTo
import com.base.app.view.BaseFragment
import com.developer.u_glow.R
import com.developer.u_glow.databinding.FragmentSubcategoryBinding
import com.developer.u_glow.model.dto.CategoryData
import com.developer.u_glow.model.dto.PostGlowData
import com.developer.u_glow.model.dto.SampleData
import com.developer.u_glow.state.booking.SelectSubCategoryState
import com.developer.u_glow.viewmodel.booking.SelectSubCategoryViewModel
import org.parceler.Parcels


class SelectSubCategoryFragment(override val layoutId: Int = R.layout.fragment_subcategory) :
    BaseFragment<SelectSubCategoryViewModel, FragmentSubcategoryBinding>() {
    var list: ArrayList<CategoryData> = ArrayList()
    override val mViewModel: SelectSubCategoryViewModel by viewModels()
    private val args: SelectSubCategoryFragmentArgs by navArgs()
    var id: Int? = null
    override fun subscribeObservers() {
        mViewModel.stateObserver.observe(this, Observer {
            when (it) {

                is SelectSubCategoryState.UpdateCategoryAdapter -> {
                    mViewBinding.rvCategory.adapter = it.adapter
                    list = it.adapter?.data as ArrayList<CategoryData>
                }

                is SelectSubCategoryState.NavigateToSubCategory -> {

                    val postGlowData = PostGlowData(id = it.data.id!!)
                    val bundle = Bundle()
                    bundle.putParcelable("post", Parcels.wrap(postGlowData))
                    findNavController().navigateTo(R.id.nav_select_glow_fragment, bundle)
                }

                else -> {
                }
            }
        })
        mViewBinding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                mViewModel.getFilterData(p0.toString(), list, requireContext())
            }
        })
    }

    override fun onFragmentCreated() {


    }


}