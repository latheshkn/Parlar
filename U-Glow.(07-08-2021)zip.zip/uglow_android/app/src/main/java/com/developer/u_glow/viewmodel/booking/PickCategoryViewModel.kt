package com.developer.u_glow.viewmodel.booking

import android.content.Context
import android.os.Bundle
import android.os.Parcelable
import androidx.lifecycle.viewModelScope
import com.base.app.model.State
import com.base.app.utils.Constants
import com.base.app.utils.Toaster
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.adapter.CategoryAdapter
import com.developer.u_glow.adapter.PickCategoryAdapter
import com.developer.u_glow.model.dto.CategoryData
import com.developer.u_glow.model.dto.PeopleData
import com.developer.u_glow.model.dto.PostArrayData
import com.developer.u_glow.model.dto.PostGlowData
import com.developer.u_glow.state.booking.DashboardState
import com.developer.u_glow.state.booking.PickCategoryState
import com.developer.u_glow.state.booking.SelectSubCategoryState
import com.developer.u_glow.webservices.ModelRepository
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import org.parceler.Parcels
import timber.log.Timber
import java.util.*
import kotlin.collections.ArrayList

class PickCategoryViewModel : BaseViewModel<PickCategoryState>() {

    private var categoryList: MutableList<CategoryData>? = null
    private var categoryAdapter: PickCategoryAdapter? = null
    var list: ArrayList<PeopleData>? = null
    var selectedItemPos = -1
    var lastItemSelectedPos = -1
    private var state: PickCategoryState = PickCategoryState.Init
        set(value) {
            field = value
            publishState(state)
        }

    override fun onInitialized(bundle: Bundle?) {
        initPeopleAdapter()
//        initCategory()

        if (bundle != null) {
            val postGlow=bundle.getParcelable<Parcelable>("post") as PostGlowData
            getAllCategory(
                postGlow.position!!, this
            )
            state = PickCategoryState.HideAndShowForMe(postGlow.forMe!!, postGlow.forGroup!!,id=postGlow.id)
            Timber.d("checkingtheId ${postGlow.id}")
        }

    }

    private fun initCategory() {
        categoryList = ArrayList()

        categoryList?.add(CategoryData("1", "Hair", "", false, true, "", false, "", false))
        categoryList?.add(CategoryData("2", "Beauty", "", true, true, "", false, "", false))
        categoryList?.add(CategoryData("3", "Pet", "", true, false, "", false, "", false))
        categoryList?.add(CategoryData("4", "God", "", false, true, "", false, "", false))
        categoryList?.add(CategoryData("5", "Layer", "", false, true, "", false, "", false))
        categoryList?.add(CategoryData("6", "Massage", "", true, true, "", false, "", false))
        categoryList?.add(CategoryData("7", "Beauty", "", false, true, "", false, "", false))
        categoryList?.add(CategoryData("8", "Hair", "", false, true, "", false, "", false))
        categoryList?.add(CategoryData("9", "Hair", "", false, false, "", false, "", false))


        categoryList!![3].select = true
        categoryAdapter = PickCategoryAdapter(categoryList as ArrayList<CategoryData>, this, true)
        state = PickCategoryState.UpdatePickCategoryAdapter(categoryAdapter)

        Timber.d("thisischeck ${categoryList.toString()}")
    }

    private fun initPeopleAdapter() {
        list = ArrayList<PeopleData>()
        list?.add(PeopleData(name = "ONE"))
        list?.add(PeopleData(name = "TWO"))
        state = PickCategoryState.SetPeopleAdapter(list!!)
    }


    fun getAllCategory(id: String, viewModel: PickCategoryViewModel) {


        viewModelScope.launch {
            ModelRepository(iRepositoryListener).getAllCategory()
                .collect {

                    when (it) {
                        is State.Success -> {

                            categoryList = it.data.data
                            categoryList!![id.toInt()].select = true
                            categoryAdapter = PickCategoryAdapter(
                                categoryList!!,
                                viewModel, true
                            )
                            state = PickCategoryState.UpdatePickCategoryAdapter(categoryAdapter)

                        }
                        is State.Error -> {
                            Timber.d("error ${it.message}")
                        }
                        else -> {

                        }
                    }
                }
        }
    }

    fun onClickSubCategory(position: Int, data: CategoryData, lastPos: Int) {
        categoryAdapter?.getAdapterPosition(position)
        state = PickCategoryState.HideAndShowForMe(data.forMe!!, data.forGroup!!, id=data.id)


    }


    fun getFilterData(searchTxt: String, list: ArrayList<CategoryData>, context: Context) {
        val filterList: ArrayList<CategoryData> = ArrayList()

        list.forEach {
            if (it.name?.toLowerCase(Locale.ROOT)?.contains(searchTxt.toLowerCase(Locale.ROOT))!!) {
                filterList.add(it)
                categoryAdapter?.updateList(filterList)
            } else {
                categoryAdapter?.updateList(filterList)
                Toaster.show(context, "No result found")
            }
        }
    }

}