package com.developer.u_glow.adapter.viewholder


import com.base.app.adapter.BaseViewHolder
import com.developer.u_glow.databinding.InflateGalleryBinding
import com.developer.u_glow.model.dto.GalleryData
import com.developer.u_glow.viewmodel.profile.GalleryViewModel


class GalleryViewHolder(
    view: InflateGalleryBinding, var viewModel:GalleryViewModel
) : BaseViewHolder<GalleryData, InflateGalleryBinding>(view) {
    override fun populateData(data: GalleryData) {

        viewBinding.ivGallery.setImageResource(data.galleryImage!!)

        viewBinding.listener=viewModel
        viewBinding.position=adapterPosition

    }
}