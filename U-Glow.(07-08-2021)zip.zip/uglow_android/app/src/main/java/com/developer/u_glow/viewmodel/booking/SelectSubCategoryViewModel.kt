package com.developer.u_glow.viewmodel.booking

import android.content.Context
import android.os.Bundle
import android.os.Parcelable
import androidx.lifecycle.viewModelScope
import com.base.app.model.State
import com.base.app.utils.Toaster
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.adapter.CategoryAdapter
import com.developer.u_glow.model.dto.CategoryData
import com.developer.u_glow.model.dto.PeopleData
import com.developer.u_glow.model.dto.PostGlowData
import com.developer.u_glow.model.dto.SampleData
import com.developer.u_glow.state.booking.DashboardState
import com.developer.u_glow.state.booking.PickCategoryState
import com.developer.u_glow.state.booking.SelectSubCategoryState
import com.developer.u_glow.webservices.ModelRepository
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import org.parceler.Parcels
import timber.log.Timber
import java.util.*
import kotlin.collections.ArrayList

class SelectSubCategoryViewModel : BaseViewModel<SelectSubCategoryState>() {

    private var categoryList: MutableList<CategoryData>? = null
    private var categoryAdapter: CategoryAdapter? = null

    private var state: SelectSubCategoryState = SelectSubCategoryState.Init
        set(value) {
            field = value
            publishState(state)
        }

    override fun onInitialized(bundle: Bundle?) {

        if (bundle != null) {


//
//                val postGlowData = Parcels.unwrap<PostGlowData>(bundle.getParcelable("post"))
//                getSubCategory(postGlowData.id.toInt(), this)
//                Timber.d("idchecking ${bundle.getString("id", "")}")

            if (bundle.getParcelable<Parcelable>("post") as PostGlowData == null) {
                val dat =
                    bundle.getParcelableArrayList<Parcelable>("post") as ArrayList<PostGlowData>

                getSubCategory(dat.get(0).id.toInt(), this)

            } else {
                val postGlow = bundle.getParcelable<Parcelable>("post") as PostGlowData
                getSubCategory(postGlow.id.toInt(), this)
            }

        }


//        getSubCategory(1, this)
    }

    private fun initCategory() {
        categoryList = ArrayList()
        for (i in 1..9) {
            categoryList?.add(CategoryData())
        }
        state = SelectSubCategoryState.UpdateCategoryAdapter(categoryAdapter)
    }

    fun onClickSubCategory(position: Int, data: CategoryData) {
        state = SelectSubCategoryState.NavigateToSubCategory(data)
    }

    fun getSubCategory(id: Int, viewModel: SelectSubCategoryViewModel) {

        viewModelScope.launch {
            ModelRepository(iRepositoryListener).getSubCategory(id).collect {
                when (it) {
                    is State.Success -> {
                        categoryList = it.data.data
                        categoryAdapter = CategoryAdapter(
                            it.data.data as MutableList<CategoryData>,
                            viewModel
                        )
                        state = SelectSubCategoryState.UpdateCategoryAdapter(categoryAdapter)
                    }
                    else -> {
                    }
                }
            }
        }
    }

    fun getFilterData(searchTxt: String, list: ArrayList<CategoryData>, context: Context) {
        val filterList: ArrayList<CategoryData> = ArrayList()

        list.forEach {
            if (it.name?.toLowerCase(Locale.ROOT)?.contains(searchTxt.toLowerCase(Locale.ROOT))!!) {
                filterList.add(it)
            } else {

                Toaster.show(context, "No result found")
            }
        }
        categoryAdapter?.updateList(filterList)
    }

}