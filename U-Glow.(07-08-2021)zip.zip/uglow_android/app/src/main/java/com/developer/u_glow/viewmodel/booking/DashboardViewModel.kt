package com.developer.u_glow.viewmodel.booking

import android.os.Bundle
import androidx.lifecycle.viewModelScope
import com.base.app.model.State
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.R
import com.developer.u_glow.webservices.ModelRepository
import com.developer.u_glow.adapter.BookingAdapter
import com.developer.u_glow.adapter.CategoryAdapter
import com.developer.u_glow.model.dto.BookingData
import com.developer.u_glow.model.dto.CategoryData
import com.developer.u_glow.model.request.SampleRequest
import com.developer.u_glow.state.booking.DashboardState
import com.developer.u_glow.util.Constants
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import timber.log.Timber

class DashboardViewModel : BaseViewModel<DashboardState>() {

    private var categoryList: MutableList<CategoryData>? = null
    private var categoryAdapter: CategoryAdapter? = null
    private var bookingList: MutableList<BookingData>? = null
    private var bookingAdapter: BookingAdapter? = null

    private var state: DashboardState = DashboardState.Init
        set(value) {
            field = value
            publishState(state)
        }

    override fun onInitialized(bundle: Bundle?) {
//        initCategory()
        getAllCategory(this)
        initBooking()
    }

    private fun initBooking() {
        bookingList = ArrayList()
        for (i in 1..5) {
            bookingList?.add(BookingData())
        }
        bookingAdapter = BookingAdapter(
            bookingList as ArrayList<BookingData>,
            true,
            Constants.GlowType.booking,
            this
        )
        state = DashboardState.UpdateBookingAdapter(bookingAdapter)
    }

//    private fun initCategory() {
//        categoryList = ArrayList()
//        for (i in 1..9) {
//            categoryList?.add(CategoryData())
//        }
//        categoryAdapter = CategoryAdapter(categoryList as ArrayList<CategoryData>, this)
//        state = DashboardState.UpdateCategoryAdapter(categoryAdapter)
//    }

    fun onClickCategory(position: Int, data: CategoryData) {
        state = DashboardState.NavigateToSubCategory(data,position)
        data.select !=data.select
    }

    /**Sample api integration**/
    fun performSampleApi() {
        val sampleRequest = SampleRequest()
        viewModelScope.launch {
            ModelRepository(iRepositoryListener)
                .updateSampleInfo(sampleRequest).collect {
                    when (it) {
                        is State.Success -> {
                            /** it.data will have the response object **/
                        }

                        else -> {
                        }
                    }
                }
        }
    }

    private fun getAllCategory(viewModel: Any) {

        viewModelScope.launch {
            ModelRepository(iRepositoryListener).getAllCategory().collect {

                when (it) {
                    is State.Success -> {
                        state = if (it.data.data?.size!! > 9) {
                            DashboardState.ShowMore(true)
                        } else {
                            DashboardState.ShowMore(false)
                        }
                        categoryList = it.data.data
                        categoryAdapter = CategoryAdapter(
                            it.data.data as MutableList<CategoryData>,
                            viewModel
                        )
                        state = DashboardState.UpdateCategoryAdapter(categoryAdapter)
                    }

                    else -> {

                    }
                }
            }
        }
    }


    fun showMore(show:Boolean,list:ArrayList<CategoryData>){
        categoryAdapter?.setLoadMore(show,list)
        categoryAdapter?.notifyDataSetChanged()

    }
}