package com.developer.u_glow.state.analytics

sealed class AnalyticsFragmentState{

}
