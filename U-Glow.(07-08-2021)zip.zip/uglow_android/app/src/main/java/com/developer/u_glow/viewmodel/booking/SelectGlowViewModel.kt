package com.developer.u_glow.viewmodel.booking

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.os.Parcelable
import androidx.lifecycle.viewModelScope
import androidx.navigation.Navigation.findNavController
import com.base.app.model.State
import com.base.app.utils.Toaster
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.R
import com.developer.u_glow.adapter.SelectGlowAdapter
import com.developer.u_glow.adapter.AddServiceAdapter
import com.developer.u_glow.model.dto.PostGlowData
import com.developer.u_glow.model.dto.SampleData
import com.developer.u_glow.model.dto.ServiceData
import com.developer.u_glow.state.booking.SelectGlowFragmentState
import com.developer.u_glow.util.PrefConfig
import com.developer.u_glow.webservices.ModelRepository
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import org.intellij.lang.annotations.PrintFormat
import org.parceler.Parcels
import timber.log.Timber


class SelectGlowViewModel : BaseViewModel<SelectGlowFragmentState>() {
    private var selectGlowList: MutableList<ServiceData>? = ArrayList()
    var list: MutableList<ServiceData>? = ArrayList()
    private var selectGlowAdapter: SelectGlowAdapter? = null
    private var addServiceList: MutableList<ServiceData>? = ArrayList()
    private var addServiceAdapter: AddServiceAdapter? = null
    var id: Int? = null

    private var state: SelectGlowFragmentState = SelectGlowFragmentState.Init
        set(value) {
            field = value
            publishState(state)
        }

    override fun onInitialized(bundle: Bundle?) {
//        initSelectGlow()


//        val dat = bundle?.getParcelableArrayList<Parcelable>("post") as ArrayList<SampleData>
//        Timber.d("dfatl ${dat.get(1).id}")
        val postGlow = Parcels.unwrap<PostGlowData>(bundle?.getParcelable("post"))
        if (bundle != null) {
            getService(postGlow.id.toInt(), this)
            Timber.d("idchecking ${postGlow.id.toInt()}")
//
        }

        id = postGlow.id.toInt()

    }

    private fun initSelectGlow() {

        selectGlowAdapter = SelectGlowAdapter(selectGlowList as ArrayList<ServiceData>, this)
        state = SelectGlowFragmentState.SetSelectGlowAdapter(selectGlowAdapter!!)

    }


    fun onClickAddData(data: ServiceData, context: Context) {

        addServiceList?.add(data)
        addServiceAdapter = AddServiceAdapter(addServiceList as ArrayList<ServiceData>, this)
        state = SelectGlowFragmentState.SetAddServiceAdapter(addServiceAdapter!!)

        Timber.d("servicesadd")
    }

    fun deleteService(position: Int) {
        addServiceAdapter?.removeItem(position)
        addServiceAdapter?.notifyDataSetChanged()

    }

    private fun getService(id: Int, viewModel: SelectGlowViewModel) {

        viewModelScope.launch {

            ModelRepository(iRepositoryListener).getService(id).collect {
                when (it) {
                    is State.Success -> {
                        selectGlowAdapter =
                            SelectGlowAdapter(it.data.data as MutableList<ServiceData>, viewModel)
                        state = SelectGlowFragmentState.SetSelectGlowAdapter(selectGlowAdapter!!)

                    }
                    else -> {
                    }
                }
            }
        }

    }

    fun getId(): Int {
        if (id != null) {
            return id!!
        } else {
            return null!!
        }
    }
}