package com.developer.u_glow.model.dto

data class PostArrayData(
    var data:ArrayList<SelectGlowData>
)
