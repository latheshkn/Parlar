package com.developer.u_glow.viewmodel.settings

import android.os.Bundle
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.state.settings.SettingsFragmentState

class SettingViewModel:BaseViewModel<SettingsFragmentState>() {
    override fun onInitialized(bundle: Bundle?) {
    }
}