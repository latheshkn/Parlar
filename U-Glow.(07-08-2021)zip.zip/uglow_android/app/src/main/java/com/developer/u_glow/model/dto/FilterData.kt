package com.developer.u_glow.model.dto

data class FilterData(
    val name: String? = null
)