package com.developer.u_glow.model.dto

data class FaqData(
    var question:String?=null,
    var answer:String?=null
)
