package com.developer.u_glow.viewmodel.settings

import android.os.Bundle
import com.base.app.viewmodel.BaseViewModel
import com.developer.u_glow.state.settings.SettingPassportFragmentState

class SettingPassportViewModel:BaseViewModel<SettingPassportFragmentState>() {
    override fun onInitialized(bundle: Bundle?) {

    }
}