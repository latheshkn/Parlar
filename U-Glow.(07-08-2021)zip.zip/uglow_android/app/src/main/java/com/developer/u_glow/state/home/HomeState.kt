package com.developer.u_glow.state.home

sealed class HomeState {
    object Init : HomeState()
}