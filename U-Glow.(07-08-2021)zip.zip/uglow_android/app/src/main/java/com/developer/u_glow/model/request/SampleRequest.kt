package com.developer.u_glow.model.request

data class SampleRequest(
    var sample: String? = ""
)