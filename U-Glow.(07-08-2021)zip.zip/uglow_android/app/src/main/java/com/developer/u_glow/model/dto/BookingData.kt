package com.developer.u_glow.model.dto

data class BookingData(
    var title: String? = null,
    var location: String? = null
)