package com.developer.u_glow.model.dto

data class NotificationData(
    var content: String? = null,
    var title: String? = null
)