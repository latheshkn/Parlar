package com.developer.u_glow.model.dto

data class OptionData(
    var color: Int? = null,
    var title: Int? = null
)