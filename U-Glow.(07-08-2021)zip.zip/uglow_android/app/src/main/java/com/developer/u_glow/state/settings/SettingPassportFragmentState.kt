package com.developer.u_glow.state.settings

sealed class SettingPassportFragmentState{

}
