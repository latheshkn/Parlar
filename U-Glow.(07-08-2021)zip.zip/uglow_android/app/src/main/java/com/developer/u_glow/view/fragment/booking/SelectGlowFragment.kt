package com.developer.u_glow.view.fragment.booking

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Parcelable
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import bolts.AppLinkNavigation.navigate
import com.base.app.view.BaseFragment
import com.developer.u_glow.R
import com.developer.u_glow.adapter.AddServiceAdapter
import com.developer.u_glow.databinding.FragmentSelectGlowBinding
import com.developer.u_glow.model.dto.PostGlowData
import com.developer.u_glow.model.dto.SampleData
import com.developer.u_glow.state.booking.SelectGlowFragmentState
import com.developer.u_glow.util.PrefConfig
import com.developer.u_glow.viewmodel.booking.SelectGlowViewModel
import org.parceler.Parcels
import timber.log.Timber


class SelectGlowFragment : BaseFragment<SelectGlowViewModel, FragmentSelectGlowBinding>() {
    override val mViewModel: SelectGlowViewModel by viewModels()
    override val layoutId: Int
        get() = R.layout.fragment_select_glow
    var adapter: AddServiceAdapter? = null
    override fun subscribeObservers() {
        mViewModel.stateObserver.observe(this, Observer {
            when (it) {
                is SelectGlowFragmentState.SetSelectGlowAdapter -> {
                    mViewBinding.rvSelectGlow.adapter = it.selectGlowAdapter
                }
                is SelectGlowFragmentState.SetAddServiceAdapter -> {
                    mViewBinding.rvAddService.adapter = it.addServiceAdapter
//                    PrefConfig.WriteList(requireContext(),it.addServiceAdapter.list)
                }
                is SelectGlowFragmentState.SaveList -> {


                }
                else -> {

                }
            }
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onFragmentCreated() {

        mViewBinding.viewModel = mViewModel
        mViewBinding.view = this
        mViewBinding.id = mViewModel.getId()
        mViewBinding.cardEnterDetailsWant.setOnTouchListener { p0, p1 ->
            if (p0?.id == R.id.cardEnterDetailsWant) {
                p0.parent.requestDisallowInterceptTouchEvent(true)

            }
            false
        }

    }

    fun onClickNavigation() {
        findNavController().navigate(R.id.nav_detail_fragment)
    }

    fun onClickNavigationBack(id: Int) {
        val bundle = Bundle()
        val sampleData = ArrayList<PostGlowData>()
        sampleData.add(PostGlowData(id=id.toString()))
        sampleData.add(PostGlowData(id="2"))
        sampleData.add(PostGlowData(id="3"))
        bundle.putParcelableArrayList("post",sampleData)
        val post= SampleData(id=3)
        bundle.putParcelable("post",Parcels.wrap(post))
        findNavController().navigate(R.id.nav_select_sub_category_fragment, bundle)
    }

}