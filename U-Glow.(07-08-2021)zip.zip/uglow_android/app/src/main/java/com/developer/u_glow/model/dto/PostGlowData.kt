package com.developer.u_glow.model.dto

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
data class PostGlowData(
    var position: String? = null,
    var forMe: Boolean? = null,
    var forGroup: Boolean? = null,
    var id: String,
    var fromNavigation:String="SelectGlow"
):Parcelable


