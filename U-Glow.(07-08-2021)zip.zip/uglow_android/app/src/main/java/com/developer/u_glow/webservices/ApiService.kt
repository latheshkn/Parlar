package com.developer.u_glow.webservices

import com.developer.u_glow.model.request.FbRequest
import com.developer.u_glow.model.request.GoogleRequest
import com.developer.u_glow.model.request.LoginRequest
import com.developer.u_glow.model.request.SampleRequest
import com.developer.u_glow.model.response.CategoryResponse
import com.developer.u_glow.model.response.LoginResponse
import com.developer.u_glow.model.response.SampleResponse
import com.developer.u_glow.model.response.SelectServiceRespose
import retrofit2.Response
import retrofit2.http.*


interface ApiService {

    @POST("v1/api/sampleApi")
    suspend fun updateSampleApi(@Body request: SampleRequest): Response<SampleResponse>

    @POST("api/v1/user/login")
    suspend fun performLogin(@Body request: LoginRequest): Response<LoginResponse>

    @POST("api/v1/user/auth/google")
    suspend fun performGoogleLogin(@Body request: GoogleRequest): Response<LoginResponse>

    @POST("api/v1/user/auth/facebook")
    suspend fun performFbLogin(@Body request: FbRequest): Response<LoginResponse>

    @GET("api/v1/category/all")
    suspend fun getAllCategory(
    ): Response<CategoryResponse>

    @GET("api/v1/category/subcategory/{id}")
    suspend fun getSubCategory(
        @Path("id") id:Int
    ): Response<CategoryResponse>

    @GET("api/v1/category/services/{id}")
    suspend fun getService(
        @Path("id") id:Int
    ): Response<SelectServiceRespose>
}